####################################################
# License                                          #
####################################################

This W3C-compliant, CSS-based website template has a 
Creative Commons Attribution-Share Alike 3.0 
Unported License.
>> http://creativecommons.org/licenses/by-sa/3.0/


####################################################
# What You Can Do                                  #
####################################################

Feel free to remix, copy, distribute and transmit 
this template. All I ask is that you keep the 
footer links in the template intact. Also, if you 
alter, transform, or build upon this work, you 
may distribute the resulting work only under the 
same, similar or a compatible license.


####################################################
# Feedback & Action                                #
####################################################

I'd love to get your feedback on the template. 
Please contact me with your critics, ideas, etc.
>> http://www.jabz.info/contact/jonas-jared-jacek/

If you like to contribute your remix, I will be 
more than happy to put your version on owmx.com
and credit you in http://www.owmx.com/credits/.

